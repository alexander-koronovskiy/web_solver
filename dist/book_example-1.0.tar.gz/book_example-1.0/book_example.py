# python lib import call as named variable (in ex.: np, plt) 
import numpy as np
import matplotlib.pyplot as plt

# argument list forming (cycle "for" used)
x = [0.1*i for i in range(100)]

# function list forming by numpy method - sin()
y = np.sin(x)

# plotting function
plt.plot(y)
plt.show()

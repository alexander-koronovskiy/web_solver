from setuptools import setup

setup(
    name='book_example',
    version='1.0',
    description='',
    author='',
    author_email='',
    url='',
    py_modules=['book_example'],
)

from setuptools import setup

setup(
    name='book_example',
    version='1.0',
    description='',
    author='alexander koronovskiy',
    author_email='alexander.koronovskiy@gmail.com',
    url='',
    py_modules=['book_example'],
)
